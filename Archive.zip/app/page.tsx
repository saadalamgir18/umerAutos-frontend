import DashboardClientPage from "./dashboard/DashboardClientPage"

export default function Home() {
  return <DashboardClientPage />
}
